from django.contrib import admin
from .models import student
from .models import teacher

# Register your models here.
@admin.register(student)
class studentadmin(admin.ModelAdmin):
    list_display = ("name","roll","add")

@admin.register(teacher)
class teacheradmin(admin.ModelAdmin):
    list_display=("name","roll","add")
