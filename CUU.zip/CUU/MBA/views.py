from django.shortcuts import render
from .models import student
from .models import teacher


# Create your views here.
def home(request):
    stu = student.objects.all()
    print(stu)
    return render(request,"home.html",{"student":stu})

def about(request):
    tec = teacher.objects.all()
    print(tec)
    return render(request,"about.html",{"teacher":tec})
    
def form(request):
    if request.method == "POST":
        Name = request.POST.get('name')
        Email = request.POST.get('email')
        Roll_no = request.POST.get('roll')
        Phone_No = request.POST.get('phone')
        Address = request.POST.get('add')
        stu = student(name = Name, email = Email, roll = Roll_no, add = Address)
        stu.save()
        print(Name, Email, Roll_no, Phone_No, Address)
    return render(request, 'form.html')
        
        