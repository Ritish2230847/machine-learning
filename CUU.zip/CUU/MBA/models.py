from django.db import models

# Create your models here.

class student(models.Model):
    name = models.CharField(max_length=100)
    roll = models.IntegerField()
    email = models.EmailField()
    add = models.CharField(max_length=200)

    def __str__(self):
       return self.name

class teacher(models.Model):
    name = models.CharField(max_length=100)
    roll = models.IntegerField()
    email = models.EmailField()
    add = models.CharField(max_length=200)

    def __str__(self):
       return self.name
    